<p align="center">
    <img alt="Polytech logo" src="http://www.tedxtours.com/wp-content/uploads/2014/11/PolytechTours.jpg" height="175"/>
</p>
<h1 align="center">Projet tutoré 4 - Java</h1>
<p align="center">
    <a alt="Travis" href="https://travis-ci.com/MrCraftCod/DI3---Projet4/"><img alt="Travis" src="https://travis-ci.com/MrCraftCod/DI3---Projet4.svg?token=s5BJCJ6gyoT4Yw4fxy1J&branch=master" /></a>
    <a href="https://codecov.io/gh/MrCraftCod/DI3---Projet4">
      <img src="https://codecov.io/gh/MrCraftCod/DI3---Projet4/branch/master/graph/badge.svg?token=Frg8BRD3F4" alt="Codecov" />
    </a>
</p>
<p align="center">
	<a alt="Travis dev" href="https://travis-ci.com/MrCraftCod/DI3---Projet4/"><img alt="Travis dev" src="https://travis-ci.com/MrCraftCod/DI3---Projet4.svg?token=s5BJCJ6gyoT4Yw4fxy1J&branch=work" /></a>
	<a href="https://codecov.io/gh/MrCraftCod/DI3---Projet4">
      <img src="https://codecov.io/gh/MrCraftCod/DI3---Projet4/branch/work/graph/badge.svg?token=Frg8BRD3F4" alt="Codecov" />
    </a>
</p>